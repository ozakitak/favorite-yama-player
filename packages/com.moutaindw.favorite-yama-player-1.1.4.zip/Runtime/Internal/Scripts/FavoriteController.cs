using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using Yamadev.YamaStream.UI;

namespace Yamadev.YamaStream
{
    public class FavoriteController : UdonSharpBehaviour
    {
        [SerializeField] private Controller _yamaController;
        [SerializeField] private UIController _uiController;
        [SerializeField] private AutoPlay _autoPlay;

        private FavoriteManager _favoriteManager;
        private bool _hasInitialized;

        public FavoriteManager GetFavoriteManager()
        {
            return _favoriteManager;
        }

        public override void OnPlayerRestored(VRCPlayerApi player)
        {
            if (!player.isLocal) return;

            // FavoriteManager を検索
            var objects = Networking.GetPlayerObjects(player);
            for (int i = 0; i < objects.Length; i++)
            {
                var favoriteManager = objects[i].GetComponentInChildren<FavoriteManager>();
                if (favoriteManager == null) continue;
                _favoriteManager = favoriteManager;
                break;
            }

            if (_favoriteManager == null) return;
            if (_yamaController == null) return;
            if (_hasInitialized) return;

            //リストUIを更新
            _yamaController.NotifyFavoritesUpdated();

            //ピンのイメージを初期化
            _yamaController.NotifyVideoPinnedChanged(_favoriteManager.isVideoPinned);

            
            
            // 途中から入った場合でも、現在再生中の動画をデフォルト動画として設定
            if (!_favoriteManager.isVideoPinned)
            {
                Track currentTrack = _yamaController.Track;
                if (currentTrack.IsValid() && _yamaController.IsPlaying)
                {
                    VRCUrl trackUrl = currentTrack.GetVRCUrl();
                    string trackTitle = currentTrack.GetTitle();
                    
                    if (trackUrl != null && !string.IsNullOrEmpty(trackUrl.Get()))
                    {
                        _favoriteManager.SetDefaultVideo(trackUrl, trackTitle);
                        Debug.Log($"[FavoriteController] Set default video from current playback: {trackTitle} ({trackUrl.Get()})");
                    }
                }
            }
            
            //デフォルト動画を再生
            if (_autoPlay != null)
            {
                if (Networking.IsMaster || _yamaController.IsLocal)
                {
                    _autoPlay.PlayDefaultTrack();
                }
            }
            _hasInitialized = true;
        }
    }
}

