using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using Yamadev.YamaStream.UI;

namespace Yamadev.YamaStream
{
    public class FavoriteController : UdonSharpBehaviour
    {
        [SerializeField] private Controller _yamaController;
        [SerializeField] private UIController _uiController;
        [SerializeField] private AutoPlay _autoPlay;

        private FavoriteManager _favoriteManager;
        private bool _hasInitialized;

        public FavoriteManager GetFavoriteManager()
        {
            return _favoriteManager;
        }

        public override void OnPlayerRestored(VRCPlayerApi player)
        {
            if (!player.isLocal) return;

            // FavoriteManager を検索
            var objects = Networking.GetPlayerObjects(player);
            for (int i = 0; i < objects.Length; i++)
            {
                var favoriteManager = objects[i].GetComponentInChildren<FavoriteManager>();
                if (favoriteManager == null) continue;
                _favoriteManager = favoriteManager;
                break;
            }

            if (_favoriteManager == null) return;
            if (_yamaController == null) return;
            if (_hasInitialized) return;

            // FavoriteManager のお気に入りを YamaPlayer の Favorites プレイリストに反映
            VRCUrl[] favoriteUrls = _favoriteManager.GetFavoriteUrls();
            string[] favoriteTitles = _favoriteManager.GetFavoriteTitles();
            Playlist favoritesPlaylist = _yamaController.Favorites;

            if (favoriteUrls == null || favoritesPlaylist == null) return;

            int addedCount = 0;
            for (int i = 0; i < favoriteUrls.Length; i++)
            {
                if (favoriteUrls[i] == null || string.IsNullOrEmpty(favoriteUrls[i].Get())) continue;

                // 既にプレイリストに存在するかチェック
                bool alreadyExists = false;
                for (int j = 0; j < favoritesPlaylist.Length; j++)
                {
                    Track existingTrack = favoritesPlaylist.GetTrack(j);
                    if (existingTrack.GetVRCUrl().Get() == favoriteUrls[i].Get())
                    {
                        alreadyExists = true;
                        break;
                    }
                }

                if (alreadyExists) continue;

                // Track を作成して追加
                string title = i < favoriteTitles.Length ? favoriteTitles[i] : favoriteUrls[i].Get();
                Track track = Track.New(_yamaController.VideoPlayerType, title, favoriteUrls[i]);
                favoritesPlaylist.AddTrack(track);
                addedCount++;
            }

            if (addedCount > 0)
            {
                Debug.Log($"[FavoriteController] Added {addedCount} favorites to YamaPlayer playlist");
            }

            //ピンを初期化
            if(_uiController != null){
                _uiController.InitializePinnedImage();
            }
            
            // 途中から入った場合でも、現在再生中の動画をデフォルト動画として設定
            if (!_favoriteManager.isVideoPinned)
            {
                Track currentTrack = _yamaController.Track;
                if (currentTrack.IsValid() && _yamaController.IsPlaying)
                {
                    VRCUrl trackUrl = currentTrack.GetVRCUrl();
                    string trackTitle = currentTrack.GetTitle();
                    
                    if (trackUrl != null && !string.IsNullOrEmpty(trackUrl.Get()))
                    {
                        _favoriteManager.SetDefaultVideo(trackUrl, trackTitle);
                        Debug.Log($"[FavoriteController] Set default video from current playback: {trackTitle} ({trackUrl.Get()})");
                    }
                }
            }
            
            //デフォルト動画を再生
            if (_autoPlay != null)
            {
                if (Networking.IsMaster || _yamaController.IsLocal)
                {
                    _autoPlay.PlayDefaultTrack();
                }
            }
            _hasInitialized = true;
        }
    }
}

