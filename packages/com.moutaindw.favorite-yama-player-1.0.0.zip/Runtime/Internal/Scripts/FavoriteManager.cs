using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace Yamadev.YamaStream
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class FavoriteManager : UdonSharpBehaviour
    {
        [Tooltip("Total limit for favorite videos")]
        [SerializeField]
        public int maxFavoriteItems = 16;

        [Tooltip("Enforce limit per user for favorite videos")]
        [SerializeField]
        [UdonSynced]
        public bool videoLimitPerUserEnabled = false;

        [Tooltip("Allow users to enter custom urls.")]
        [SerializeField]
        [UdonSynced]
        public bool customUrlInputEnabled = true;

        [Tooltip("Individual limit per user for favorite videos")]
        [SerializeField]
        [UdonSynced]
        public int videoLimitPerUser = 5;

        [UdonSynced] private VRCUrl[] favoriteUrls = new VRCUrl[0];
        [UdonSynced] private string[] favoriteTitles = new string[0];
        [UdonSynced] public bool isVideoPinned = false;        public void toggleVideoPinned()
        {
            isVideoPinned = !isVideoPinned;
            RequestSerialization();
        }
        [UdonSynced] private VRCUrl defaultUrl;
        [UdonSynced] private string defaultTitle;
        public void SetDefaultVideo(VRCUrl url, string title)
        {
            if(isVideoPinned){
                return;
            }
            defaultUrl = url;
            defaultTitle = title;
            RequestSerialization();
        }

        public int AddFavorite(VRCUrl url, string title = null)
        {
            if (!IsLocalPlayerPermittedToAddFavorite())
            {
                Debug.LogWarning("[FavoriteManager] Player not permitted to add favorite");
                return 401; // 権限なし
            }

            if (favoriteUrls.Length >= maxFavoriteItems)
            {
                Debug.LogWarning($"[FavoriteManager] Cannot add more favorites. Maximum limit ({maxFavoriteItems}) reached.");
                return 403; // 上限到達
            }

            if (url == null || string.IsNullOrEmpty(url.Get()))
            {
                Debug.LogWarning("[FavoriteManager] Empty URL detected, skipping");
                return 422; // 空のURL
            }

            // シンプルなURLバリデーション
            string urlStr = url.Get();
            int idx = urlStr.IndexOf("://", System.StringComparison.Ordinal);
            if (idx < 1 || idx > 8)
            {
                Debug.LogWarning("[FavoriteManager] Invalid URL format");
                return 400; // 無効なURL形式
            }

            EnsureOwnership();

            Debug.Log($"[FavoriteManager] Adding favorite - URL: {url.Get()}, Title: {title}");

            // 配列を拡張
            VRCUrl[] newUrls = new VRCUrl[favoriteUrls.Length + 1];
            string[] newTitles = new string[favoriteTitles.Length + 1];

            // 既存のデータをコピー
            favoriteUrls.CopyTo(newUrls, 0);
            favoriteTitles.CopyTo(newTitles, 0);

            // 新しいデータを追加
            newUrls[favoriteUrls.Length] = url;
            newTitles[favoriteTitles.Length] = title ?? url.Get();

            // 配列を更新
            favoriteUrls = newUrls;
            favoriteTitles = newTitles;

            Debug.Log($"[FavoriteManager] Successfully added favorite. New count: {favoriteUrls.Length}");

            customUrlInputEnabled = true;
            RequestSerialization();
            return 200; // 成功
        }

        public int RemoveFavorite(int index)
        {
            if (index < 0 || index >= favoriteUrls.Length)
            {
                return 400; // 無効なインデックス
            }
            
            if (!IsLocalPlayerPermittedToRemoveVideo(index))
            {
                return 401; // 権限なし
            }

            EnsureOwnership();

            // 新しい配列を作成
            VRCUrl[] newUrls = new VRCUrl[favoriteUrls.Length - 1];
            string[] newTitles = new string[favoriteTitles.Length - 1];

            // インデックスをスキップしてコピー
            int newIndex = 0;
            for (int i = 0; i < favoriteUrls.Length; i++)
            {
                if (i == index) continue;
                newUrls[newIndex] = favoriteUrls[i];
                newTitles[newIndex] = favoriteTitles[i];
                newIndex++;
            }

            // 配列を更新
            favoriteUrls = newUrls;
            favoriteTitles = newTitles;

            RequestSerialization();
            return 200; // 成功
        }

        public int FindFavoriteIndex(VRCUrl url)
        {
            if (url == null) return -1;
            string urlStr = url.Get();
            for (int i = 0; i < favoriteUrls.Length; i++)
            {
                if (favoriteUrls[i] != null && favoriteUrls[i].Get() == urlStr)
                {
                    return i;
                }
            }
            return -1;
        }

        public void EnsureOwnership()
        {
            bool wasEnabled = customUrlInputEnabled;
            if (!Networking.IsOwner(gameObject))
            {
                Networking.SetOwner(Networking.LocalPlayer, gameObject);
            }
            customUrlInputEnabled = wasEnabled;
        }

        public VRCUrl[] GetFavoriteUrls()
        {
            return favoriteUrls;
        }

        public string[] GetFavoriteTitles()
        {
            return favoriteTitles;
        }

        public VRCUrl GetFavoriteUrl(int index)
        {
            if (index < 0 || index >= favoriteUrls.Length) return null;
            return favoriteUrls[index];
        }

        public string GetFavoriteTitle(int index)
        {
            if (index < 0 || index >= favoriteTitles.Length) return "";
            return favoriteTitles[index];
        }

        public int GetFavoriteCount()
        {
            return favoriteUrls.Length;
        }

        public VRCUrl GetDefaultUrl()
        {
            return defaultUrl;
        }

        public string GetDefaultTitle()
        {
            return defaultTitle;
        }

        public bool IsLocalPlayerPermittedToAddFavorite()
        {
            // ローカルプレイヤーのみ使用するため、常に許可
            return true;
        }

        public bool IsLocalPlayerPermittedToRemoveVideo(int index)
        {
            // ローカルプレイヤーのみ使用するため、常に許可
            return true;
        }

        public override void OnDeserialization()
        {
            Debug.Log($"[FavoriteManager] OnDeserialization - FavoriteCount: {favoriteUrls.Length}");
        }
    }
}

