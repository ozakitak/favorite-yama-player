﻿
namespace Yamadev.YamaStream.UI
{
    public enum ColorType
    {
        Primary,
        Secondary,
        Info,
        Success,
        Alerm,
        Error
    }
}