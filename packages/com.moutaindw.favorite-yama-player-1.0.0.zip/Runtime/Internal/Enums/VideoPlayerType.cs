﻿
namespace Yamadev.YamaStream
{
    public enum VideoPlayerType
    {
        UnityVideoPlayer,
        AVProVideoPlayer
    }
}
