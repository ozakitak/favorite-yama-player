﻿
namespace Yamadev.YamaStream
{
    public enum PlayerPermission
    {
        Viewer,
        Editor,
        Admin,
        Owner
    }
}