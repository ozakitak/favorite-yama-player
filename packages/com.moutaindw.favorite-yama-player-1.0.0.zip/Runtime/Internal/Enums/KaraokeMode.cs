﻿
namespace Yamadev.YamaStream
{
    public enum KaraokeMode
    {
        None,
        Karaoke,
        Dance
    }
}