﻿
namespace Yamadev.YamaStream
{
    public enum AutoPlayMode
    {
        Off,
        FromTrack,
        FromPlaylist,
    }
}