using UnityEngine;

namespace RenderHeads.Media.AVProVideo
{
    public class AudioOutput : MonoBehaviour
    {
        public MediaPlayer Player { get => null; set { } }
    }
}