using UnityEngine;

namespace RenderHeads.Media.AVProVideo
{
    public class ApplyToMesh : MonoBehaviour
    {
        public MediaPlayer Player { get => null; set { } }
        public Renderer MeshRenderer { get => null; set { } }
    }
}