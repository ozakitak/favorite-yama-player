using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Yamadev.YamaStream.Editor")]