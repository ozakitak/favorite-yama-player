namespace Yamadev.YamaStream
{
    public enum ScreenType
    {
        Renderer,
        RawImage,
        Material
    }
}