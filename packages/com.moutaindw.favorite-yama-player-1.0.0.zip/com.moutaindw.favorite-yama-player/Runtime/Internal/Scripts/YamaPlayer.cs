﻿
using UnityEngine;

namespace Yamadev.YamaStream.Script
{
    public sealed class YamaPlayer : MonoBehaviour
    {
        public Transform Internal;
        public Renderer MainScreen;
    }
}