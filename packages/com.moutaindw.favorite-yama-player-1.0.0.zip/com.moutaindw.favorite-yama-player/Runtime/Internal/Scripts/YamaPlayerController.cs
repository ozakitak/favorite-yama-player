﻿
using UnityEngine;

namespace Yamadev.YamaStream.Script
{
    public class YamaPlayerController : MonoBehaviour
    {
        public YamaPlayer YamaPlayer;
    }
}